args <- commandArgs(TRUE)
df <- as.character(args[1])
write(df,"./Files/Results/PaDel/data.smi")
